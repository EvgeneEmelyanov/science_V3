package simcore.config;

/**
 * Глобальные константы симуляции.
 * Все параметры оборудования и физические коэффициенты
 * должны находиться здесь.
 */
public final class SimulationConstants {

    /** Погрешность вычислений */
    public static final double EPSILON = 1e-6;

    /** Количество точек данных (например, 20 лет почасовых данных) */
    public static final int DATA_SIZE = 175_320;

    /** Максимальное значение часовой нагрузки */
    public static final double MAX_LOAD = 1346;

    // =========================================================================
    // ===========================    ВЕТРЯК  ==================================
    // =========================================================================

    /** Пересчёт скорости ветра — эталонная высота (м) */
    public static final double WIND_REFERENCE_HEIGHT_M = 50.0;

    /** Коэффициент шероховатости z0 для логарифмического профиля */
    public static final double Z_FACTOR = 0.03;

    /** Высота мачты ВЭУ */
    public static final double MAST_HEIGHT_M = 35.0;

    // =========================================================================
    // ===========================   АККУМУЛЯТОР (Battery)  ====================
    // =========================================================================

    /** Начальный уровень заряда АКБ (0..1) */
    public static final double BATTERY_START_SOC = 1.0;

    /** Минимальный уровень заряда (бывший MIN_CAPACITY = 0.2) */
    public static final double BATTERY_MIN_SOC = 0.20;

    /** Максимальный уровень заряда (normal = 1.0) */
    public static final double BATTERY_MAX_SOC = 1.00;

    /** КПД заряда/разряда */
    public static final double BATTERY_EFFICIENCY = 0.93;

    /** Саморазряд 3% в месяц = 3%/мес */
    public static final double BATTERY_SELF_DISCHARGE_PER_HOUR = 0.03 / 720.0;

    /** Минимальный остаток ёмкости при разряде (в долях от номинала) */
    public static final double BATTERY_MIN_RESERVE = 0.05;

    /** Порог деградации: maxCapacity <= 0.8 * nominal */
    public static final double BATTERY_DEGRADATION_THRESHOLD = 0.8;

    /** Скорость деградации (параметр старения из старого кода) */
    public static final double BATTERY_DEGRADATION_RATE = 0.0025;

    // =========================================================================
    // ===========================    ДИЗЕЛЬ  ==================================
    // =========================================================================

    /** Минимальная мощность ДГУ (в долях) */
    public static final double DG_MIN_POWER = 0.3;

    /** Максимальная мощность ДГУ (в долях) */
    public static final double DG_MAX_POWER = 1;

    /** Оптимальная максимальная загрузка ДГУ (в долях) */
    public static final double DG_OPTIMAL_POWER = 0.8;

    /** Задержка первого пуска ДГУ (из старого FirstTimeStart) */
    public static final double DG_START_DELAY_HOURS = 0.1; // 0.05

    /** Максимальная длительность работы на низкую загрузку */
    public static final int DG_MAX_IDLE_HOURS = 4;

    // =========================================================================
    // ===========================    ПРОЧЕЕ   =================================
    // =========================================================================



    private SimulationConstants() {}
}
